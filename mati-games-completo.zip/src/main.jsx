import React,{useEffect,useRef,useState} from "react";
import {createRoot} from "react-dom/client";
import {Home,User,Users,Gamepad2,Video,Coins,Gift,ShoppingBag,Plus,Heart,MessageCircle,Share2,Camera,Image as ImageIcon,Send,Menu,X,LogOut,Settings,Upload,Shield,FileText,Play,Search} from "lucide-react";
import "./styles.css";

const seedUsers=[
 {id:1,name:"Mati",handle:"@mati",avatar:"",bio:"Criador do Mati Games 🎮👑",following:120,followers:450,online:true},
 {id:2,name:"Gamer BR",handle:"@gamerbr",avatar:"",bio:"Roblox • Minecraft • Fortnite",following:80,followers:220},
 {id:3,name:"Luna Gamer",handle:"@lunagamer",avatar:"",bio:"Lives e vídeos todos os dias ✨",following:310,followers:1200}
];
const seedPosts=[
 {id:1,user:2,text:"Quem vai jogar hoje? 🎮🔥",likes:32,comments:5},
 {id:2,user:3,text:"Live começando às 20h! Mandem presentes durante a live 💜",likes:76,comments:12}
];
const games=["Roblox","Minecraft","Fortnite","Free Fire","GTA V","Brawl Stars"];
const packs=[1,5,10,50,100,500,1000,10000,100000];

function load(k,f){try{return JSON.parse(localStorage.getItem(k))??f}catch{return f}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function App(){
 const [tab,setTab]=useState("home"),[menu,setMenu]=useState(false);
 const [me,setMe]=useState(()=>load("mg_me",seedUsers[0]));
 const [users,setUsers]=useState(()=>load("mg_users",seedUsers));
 const [posts,setPosts]=useState(()=>load("mg_posts",seedPosts));
 const [friends,setFriends]=useState(()=>load("mg_friends",[]));
 const [groups,setGroups]=useState(()=>load("mg_groups",[]));
 const [coins,setCoins]=useState(()=>load("mg_coins",0));
 const [toast,setToast]=useState("");
 const [camera,setCamera]=useState(false);
 const [game,setGame]=useState(null);
 const videoRef=useRef(null);
 useEffect(()=>save("mg_me",me),[me]); useEffect(()=>save("mg_users",users),[users]);
 useEffect(()=>save("mg_posts",posts),[posts]); useEffect(()=>save("mg_friends",friends),[friends]);
 useEffect(()=>save("mg_groups",groups),[groups]); useEffect(()=>save("mg_coins",coins),[coins]);
 const notify=m=>{setToast(m);setTimeout(()=>setToast(""),2200)}
 const avatarStyle=u=>u.avatar?{backgroundImage:`url(${u.avatar})`}:{};
 const userById=id=>users.find(u=>u.id===id)||seedUsers[0];
 const pickImage=e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>setMe({...me,avatar:r.result});r.readAsDataURL(f)}
 async function startCamera(){setCamera(true);try{const s=await navigator.mediaDevices.getUserMedia({video:true});videoRef.current.srcObject=s}catch{notify("Não foi possível acessar a câmera.")}}
 function snap(){const c=document.createElement("canvas");c.width=videoRef.current.videoWidth;c.height=videoRef.current.videoHeight;c.getContext("2d").drawImage(videoRef.current,0,0);setMe({...me,avatar:c.toDataURL("image/jpeg")});videoRef.current.srcObject?.getTracks().forEach(t=>t.stop());setCamera(false)}
 const nav=(t)=>{setTab(t);setMenu(false)}
 return <div className="app">
  <header><div className="brand" onClick={()=>nav("home")}><span>👑</span><b>Mati Games</b><span>👑</span></div>
   <div className="head-actions"><button onClick={()=>nav("search")}><Search/></button><button onClick={()=>setMenu(!menu)}><Menu/></button></div>
  </header>
  {menu&&<div className="drawer"><button onClick={()=>nav("profile")}><User/> Meu perfil</button><button onClick={()=>nav("groups")}><Users/> Grupos</button><button onClick={()=>nav("games")}><Gamepad2/> Jogos</button><button onClick={()=>nav("shop")}><Coins/> Moedas e presentes</button><button onClick={()=>nav("settings")}><Settings/> Configurações</button></div>}
  <main>
   {tab==="home"&&<HomePage me={me} posts={posts} userById={userById} setPosts={setPosts} notify={notify} nav={nav}/>}
   {tab==="profile"&&<Profile me={me} setMe={setMe} users={users} friends={friends} setFriends={setFriends} notify={notify} pickImage={pickImage} startCamera={startCamera}/>}
   {tab==="friends"&&<Friends users={users} friends={friends} setFriends={setFriends} notify={notify}/>}
   {tab==="games"&&<Games me={me} setGame={setGame} notify={notify}/>}
   {tab==="groups"&&<Groups groups={groups} setGroups={setGroups} notify={notify}/>}
   {tab==="videos"&&<Videos notify={notify}/>}
   {tab==="live"&&<Live me={me} coins={coins} setCoins={setCoins} notify={notify}/>}
   {tab==="shop"&&<Shop coins={coins} setCoins={setCoins} notify={notify}/>}
   {tab==="search"&&<SearchPage users={users} setFriends={setFriends} friends={friends} notify={notify}/>}
   {tab==="settings"&&<SettingsPage notify={notify}/>}
  </main>
  <nav className="bottom"><Nav icon={<Home/>} label="Início" active={tab==="home"} onClick={()=>nav("home")}/><Nav icon={<Video/>} label="Vídeos" active={tab==="videos"} onClick={()=>nav("videos")}/><Nav icon={<Plus/>} label="Criar" active={false} onClick={()=>nav("videos")}/><Nav icon={<Gamepad2/>} label="Jogos" active={tab==="games"} onClick={()=>nav("games")}/><Nav icon={<User/>} label="Perfil" active={tab==="profile"} onClick={()=>nav("profile")}/></nav>
  {toast&&<div className="toast">{toast}</div>}
  {camera&&<div className="modal"><div className="modalbox"><h2>Tirar foto</h2><video ref={videoRef} autoPlay playsInline/><div className="row"><button className="primary" onClick={snap}><Camera/> Capturar</button><button onClick={()=>{videoRef.current?.srcObject?.getTracks().forEach(t=>t.stop());setCamera(false)}}>Cancelar</button></div></div></div>}
  {game&&<GameDonation game={game} me={me} close={()=>setGame(null)} notify={notify}/>}
 </div>
}
function Nav({icon,label,active,onClick}){return <button className={active?"active":""} onClick={onClick}>{icon}<small>{label}</small></button>}
function HomePage({me,posts,userById,setPosts,notify,nav}){
 const [text,setText]=useState("");
 const add=()=>{if(!text.trim())return;setPosts([{id:Date.now(),user:me.id,text,likes:0,comments:0},...posts]);setText("");notify("Publicação criada!")}
 return <section className="home">
  <div className="hero"><div className="games-bg">🎮 🕹️ 🎧 👾 🏆 🎮 👑 🕹️ 👾</div><h1>👑 Mati Games 👑</h1><p>E é aqui que a diversão começa.</p><strong>🚀 Em breve: nosso app para vocês baixarem!</strong><div className="credits">Desenvolvedor: <b>Mati</b><br/>Tecnologias: React • Vite • CSS • armazenamento local</div></div>
  <div className="card composer"><div className="avatar" style={me.avatar?{backgroundImage:`url(${me.avatar})`}:{}}>{!me.avatar&&"M"}</div><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="O que está acontecendo no Mati Games?"/><button className="primary" onClick={add}><Send/> Publicar</button></div>
  <div className="quick"><button onClick={()=>nav("live")}><Video/> Fazer live</button><button onClick={()=>nav("videos")}><Camera/> Vídeo</button><button onClick={()=>nav("shop")}><Gift/> Presente</button></div>
  {posts.map(p=>{const u=userById(p.user);return <article className="card post" key={p.id}><div className="posthead"><div className="avatar" style={u.avatar?{backgroundImage:`url(${u.avatar})`}:{}}>{!u.avatar&&u.name[0]}</div><div><b>{u.name}</b><span>{u.handle}</span></div></div><p>{p.text}</p><div className="postactions"><button onClick={()=>setPosts(posts.map(x=>x.id===p.id?{...x,likes:x.likes+1}:x))}><Heart/> {p.likes}</button><button><MessageCircle/> {p.comments}</button><button onClick={()=>notify("Link pronto para compartilhar!") }><Share2/> Compartilhar</button></div></article>})}
 </section>
}
function Profile({me,setMe,users,friends,setFriends,notify,pickImage,startCamera}){
 const [bio,setBio]=useState(me.bio||""); const [pix,setPix]=useState(me.pix||"");
 const saveIt=()=>{setMe({...me,bio,pix});notify("Perfil salvo!")}
 return <section><div className="profileCover"><div className="bigavatar" style={me.avatar?{backgroundImage:`url(${me.avatar})`}:{}}>{!me.avatar&&me.name[0]}</div><h1>{me.name}</h1><span>{me.handle}</span><p>{bio}</p></div>
 <div className="card"><h2>Foto de perfil</h2><div className="row"><label className="button"><ImageIcon/> Galeria<input hidden type="file" accept="image/*" onChange={pickImage}/></label><button onClick={startCamera}><Camera/> Tirar foto</button></div></div>
 <div className="card form"><label>Nome de exibição<input value={me.name} onChange={e=>setMe({...me,name:e.target.value})}/></label><label>Bio<textarea value={bio} onChange={e=>setBio(e.target.value)}/></label><label>Chave Pix (opcional)<input value={pix} onChange={e=>setPix(e.target.value)} placeholder="Sua chave Pix"/></label><button className="primary" onClick={saveIt}>Salvar perfil</button></div>
 <div className="stats"><b>{me.followers}<small>Seguidores</small></b><b>{me.following}<small>Seguindo</small></b><b>{friends.length}<small>Amigos</small></b></div>
 </section>
}
function Friends({users,friends,setFriends,notify}){return <section><h1>👥 Amizades</h1>{users.filter(u=>u.id!==1).map(u=><div className="card userrow" key={u.id}><div className="avatar">{u.name[0]}</div><div><b>{u.name}</b><span>{u.handle}</span></div><button onClick={()=>{if(!friends.includes(u.id)){setFriends([...friends,u.id]);notify("Pedido de amizade enviado!")}else notify("Vocês já são amigos.")}}>{friends.includes(u.id)?"✓ Amigo":"+ Amizade"}</button></div>)}</section>}
function Games({me,setGame,notify}){const [handles,setHandles]=useState({});return <section><h1>🎮 Jogos</h1><p className="muted">Digite seu usuário em cada jogo para montar seu perfil gamer.</p><div className="gamegrid">{games.map(g=><div className="card game" key={g}><div className="gameicon">🎮</div><h2>{g}</h2><input placeholder="Seu usuário no jogo" value={handles[g]||""} onChange={e=>setHandles({...handles,[g]:e.target.value})}/><button className="primary" onClick={()=>handles[g]?notify(`Perfil ${g} salvo como ${handles[g]}`):notify("Digite o usuário primeiro.")}>Salvar perfil</button><button onClick={()=>setGame(g)}>Doação / opções</button></div>)}</div></section>}
function GameDonation({game,close,notify}){const [to,setTo]=useState("");return <div className="modal"><div className="modalbox"><button className="close" onClick={close}><X/></button><h2>🎮 {game}</h2><p>As transações do jogo devem ser feitas no site oficial.</p><label>Usuário da pessoa<input value={to} onChange={e=>setTo(e.target.value)} placeholder="Nome de usuário"/></label><button className="primary" onClick={()=>notify("Use o site oficial do jogo para concluir a doação.")}>Abrir opções oficiais</button><button onClick={()=>notify("Pedido de amizade preparado!")}>+ Pedir amizade no jogo</button></div></div>}
function Groups({groups,setGroups,notify}){const [name,setName]=useState("");return <section><h1>👥 Grupos</h1><div className="card form"><input placeholder="Nome do novo grupo" value={name} onChange={e=>setName(e.target.value)}/><button className="primary" onClick={()=>{if(name){setGroups([...groups,{id:Date.now(),name,members:1}]);setName("");notify("Grupo criado!")}}}><Plus/> Criar grupo</button></div>{groups.map(g=><div className="card userrow" key={g.id}><Users/><b>{g.name}</b><span>{g.members} membro(s)</span><button onClick={()=>notify("Convite para o grupo copiado!")}>Convidar</button></div>)}</section>}
function Videos({notify}){const [video,setVideo]=useState(null);return <section><h1>🎬 Vídeos</h1><div className="card"><label className="button"><Upload/> Gravar/enviar vídeo<input hidden type="file" accept="video/*" capture="environment" onChange={e=>{setVideo(URL.createObjectURL(e.target.files[0]));notify("Vídeo carregado para pré-visualização.")}}/></label>{video&&<video className="preview" controls src={video}/>}</div><div className="card videoFake"><div>▶️</div><h2>Feed de vídeos</h2><p>Curta, comente e compartilhe como em uma rede de vídeos curtos.</p><div className="postactions"><button onClick={()=>notify("Curtida!")}>❤️ Curtir</button><button onClick={()=>notify("Comentário aberto!")}>💬 Comentar</button><button onClick={()=>notify("Compartilhamento pronto!")}>↗️ Compartilhar</button></div></div></section>}
function Live({me,coins,setCoins,notify}){return <section><h1>🔴 Lives</h1><div className="card live"><div className="liveScreen"><Play/></div><h2>{me.name} — Live do Mati Games</h2><p>Espectadores podem enviar presentes ou Pix.</p><button className="primary" onClick={()=>{if(coins>0){setCoins(coins-1);notify("Presente de 1 moeda enviado!")}else notify("Compre moedas para enviar presentes.")}}><Gift/> Enviar 1 moeda</button><button onClick={()=>notify("Chave Pix exibida na bio do criador.")}>💸 Enviar Pix</button></div></section>}
function Shop({coins,setCoins,notify}){return <section><h1>🪙 Moedas e presentes</h1><div className="balance">Saldo: <b>{coins.toLocaleString("pt-BR")} moedas</b></div><p className="muted">1 moeda = R$ 0,50. Valores abaixo são demonstração até conectar um gateway de pagamento.</p><div className="packgrid">{packs.map(n=><div className="card pack" key={n}><Coins/><b>{n.toLocaleString("pt-BR")}</b><span>R$ {(n*.5).toLocaleString("pt-BR",{minimumFractionDigits:2})}</span><button className="primary" onClick={()=>{setCoins(coins+n);notify(`${n} moedas adicionadas em modo de teste.`)}}>Comprar teste</button></div>)}</div><div className="card"><h2>🎁 Presentes</h2><p>Envie presentes de 1 até 100.000 moedas durante lives.</p></div></section>}
function SearchPage({users,setFriends,friends,notify}){const [q,setQ]=useState("");return <section><h1>🔎 Buscar</h1><input className="search" placeholder="Nome ou @usuário" value={q} onChange={e=>setQ(e.target.value)}/>{users.filter(u=>(u.name+u.handle).toLowerCase().includes(q.toLowerCase())).map(u=><div className="card userrow" key={u.id}><div className="avatar">{u.name[0]}</div><div><b>{u.name}</b><span>{u.handle}</span></div>{u.id!==1&&<button onClick={()=>{setFriends([...new Set([...friends,u.id])]);notify("Pedido de amizade enviado!")}}>+ Amizade</button>}</div>)}</section>}
function SettingsPage({notify}){return <section><h1>⚙️ Configurações</h1><div className="card"><h2>Plano de arquivos</h2><p>Envio de PDFs e arquivos pessoais: R$ 10/mês.</p><button className="primary" onClick={()=>notify("Assinatura em modo de demonstração.")}>Assinar teste</button></div><div className="card"><Shield/><h2>Conta ADM</h2><p>Recursos administrativos podem ser liberados pelo backend seguro.</p></div><div className="card"><h2>📢 Promoções</h2><p>Calendário de promoções mensais preparado para ser configurado pelo ADM.</p></div></section>}
createRoot(document.getElementById("root")).render(<App/>);
# Mati Games

Projeto React/Vite de demonstração do site Mati Games.

## Rodar
1. Instale Node.js.
2. Entre nesta pasta.
3. Rode `npm install`.
4. Rode `npm run dev`.

## Recursos incluídos
Perfil com foto da galeria/câmera, amizades, seguidores, posts, vídeos, jogos e usuários de jogos, grupos, lives demonstrativas, moedas e presentes, busca, Pix na bio e área de configurações.

## Importante
Compra de moedas, Pix, assinaturas, Robux e transações de jogos estão em modo de demonstração. Para produção, use backend seguro, autenticação, banco de dados e um provedor de pagamentos oficial. Doações/itens de jogos de terceiros devem ser concluídos nos sites oficiais.
